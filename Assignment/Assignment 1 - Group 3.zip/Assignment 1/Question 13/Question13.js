


    

    let fruits = ["Banana", "Orange", "Apple", "Mango"];

    let last = fruits[fruits.length-1];
    
    const para = document.querySelector('p');
    para.append(` ${last}`); 
 