let firstName, lastName, age;

          firstName = prompt("Hello there, please enter your First name: ")
          lastName =prompt("Now, enter your lastname:")
          age = prompt("And Age: ");

          alert(`Hi ${firstName} ${lastName}, you are ${age} which is wonderful!`)