let x = 5;
let y = 10;
document.getElementById("demo").innerHTML=x+y;